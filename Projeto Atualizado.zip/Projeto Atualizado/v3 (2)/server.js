const express = require('express');
const mongoose = require('mongoose');
const app = express();
const PORT = 3000;

// Conexão com o MongoDB
mongoose.connect('mongodb://localhost:27017/matchApp', { useNewUrlParser: true, useUnifiedTopology: true });

const profileSchema = new mongoose.Schema({
    name: String,
    img: String
});

const Profile = mongoose.model('Profile', profileSchema);

app.use(express.json());

// Rota para obter perfis
app.get('/profiles', async (req, res) => {
    const profiles = await Profile.find();
    res.json(profiles);
});

// Rota para adicionar um perfil
app.post('/profiles', async (req, res) => {
    const newProfile = new Profile(req.body);
    await newProfile.save();
    res.status(201).json(newProfile);
});

app.listen(PORT, () => {
    console.log("Server is running on '${http://localhost:${PORT}");
});