let matchedProfiles = [];

function showPage(page) {
    let content = document.getElementById('content');
    if (page === 'like-dislike') {
        content.innerHTML = `
            <div class="container">
                <div class="card">
                    <img src="https://via.placeholder.com/150" alt="Profile Picture">
                    <h2 id="profile-name">Nome da Pessoa</h2>
                </div>
                <div class="actions">
                    <button id="dislikeBtn" class="dislike">X</button>
                    <button id="likeBtn" class="like">❤️</button>
                </div>
                <div id="match-notification" class="notification hidden">
                    <p>Vocês deram um match!</p>
                </div>
            </div>
        `;
        initializeLikeDislike();
    } else if (page === 'chat') {
        content.innerHTML = '<h1>Bate papo</h1><div class="chat-container" id="chat-container"></div>';
        updateChat();
    } else if (page === 'profile') {
        content.innerHTML = '<h1>Perfil</h1><p>Conteúdo da página Perfil.</p>';
    }
}

function initializeLikeDislike() {
    const likeBtn = document.getElementById('likeBtn');
    const dislikeBtn = document.getElementById('dislikeBtn');
    const matchNotification = document.getElementById('match-notification');
    const profileName = document.getElementById('profile-name');
    const profileImg = document.querySelector('.card img');

    let likeCount = 0; // Contador de curtidas
    let isMatched = false; // Flag para verificar se houve match

    // Lista de perfis com nomes e fotos simuladas
    const profiles = [
        { name: 'Maria', img: 'https://randomuser.me/api/portraits/women/44.jpg' },
        { name: 'João', img: 'https://randomuser.me/api/portraits/men/44.jpg' },
        { name: 'Ana', img: 'https://randomuser.me/api/portraits/women/45.jpg' },
        { name: 'Pedro', img: 'https://randomuser.me/api/portraits/men/45.jpg' },
        { name: 'Juliana', img: 'https://randomuser.me/api/portraits/women/46.jpg' },
        { name: 'Lucas', img: 'https://randomuser.me/api/portraits/men/46.jpg' },
        { name: 'Carla', img: 'https://randomuser.me/api/portraits/women/47.jpg' },
        { name: 'Felipe', img: 'https://randomuser.me/api/portraits/men/47.jpg' },
        { name: 'Fernanda', img: 'https://randomuser.me/api/portraits/women/48.jpg' },
        { name: 'Rodrigo', img: 'https://randomuser.me/api/portraits/men/48.jpg' },
        { name: 'Gabriela', img: 'https://randomuser.me/api/portraits/women/49.jpg' },
        { name: 'Bruno', img: 'https://randomuser.me/api/portraits/men/49.jpg' }
    ];

    let currentProfileIndex = 0;

    // Função para atualizar o perfil
    function updateProfile() {
        if (!isMatched) { // Somente atualizar se não houver match
            const profile = profiles[currentProfileIndex];
            profileName.textContent = profile.name;
            profileImg.src = profile.img;
        }
    }

    // Inicializar o primeiro perfil
    updateProfile();

    likeBtn.addEventListener('click', () => {
        likeCount++;
        if (likeCount >= 5) {
            isMatched = true;
            matchNotification.classList.remove('hidden');
            matchNotification.classList.add('visible');
            matchedProfiles.push(profiles[currentProfileIndex]);
            setTimeout(() => {
                matchNotification.classList.remove('visible');
                matchNotification.classList.add('hidden');
                isMatched = false; // Resetar o flag de match
                likeCount = 0; // Resetar o contador de curtidas
                updateProfile(); // Atualizar o perfil para continuar dando likes/deslikes
            }, 3000); // Esperar 3 segundos antes de desaparecer a notificação
        } else {
            currentProfileIndex = (currentProfileIndex + 1) % profiles.length;
            updateProfile();
        }
    });

    dislikeBtn.addEventListener('click', () => {
        currentProfileIndex = (currentProfileIndex + 1) % profiles.length;
        updateProfile();
    });
}

function updateChat() {
    const chatContainer = document.getElementById('chat-container');
    chatContainer.innerHTML = '';
    matchedProfiles.forEach(profile => {
        const profileElement = document.createElement('div');
        profileElement.classList.add('chat-profile');
        profileElement.innerHTML = `
            <img src="${profile.img}" alt="Profile Picture">
            <p>${profile.name}</p>
        `;
        chatContainer.appendChild(profileElement);
    });
}
